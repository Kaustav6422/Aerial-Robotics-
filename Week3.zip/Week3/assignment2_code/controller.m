function [ u1, u2 ] = controller(~, state, des_state, params)
%CONTROLLER  Controller for the planar quadrotor
%
%   state: The current state of the robot with the following fields:
%   state.pos = [y; z], state.vel = [y_dot; z_dot], state.rot = [phi],
%   state.omega = [phi_dot]
%
%   des_state: The desired states are:
%   des_state.pos = [y; z], des_state.vel = [y_dot; z_dot], des_state.acc =
%   [y_ddot; z_ddot]
%
%   params: robot parameters

%   Using these current and desired states, you have to compute the desired
%   controls

% FILL IN YOUR CODE HERE


% Control gains
kp_y = 21;
kd_y = 6;
kp_z = 78;
kd_z = 18;
kp_phi = 1000;
kd_phi = 10;


% Desired Trajectory
zdes_dotdot = des_state.acc(2,1);
ydes_dotdot = des_state.acc(1,1);
zdes_dot    = des_state.vel(2,1) ;
ydes_dot    = des_state.vel(1,1) ;
zdes        = des_state.pos(2,1) ;
ydes        = des_state.pos(1,1) ;

% State
z_dot = state.vel(2,1) ;
y_dot = state.vel(1,1) ;
z     = state.pos(2,1) ;
y     = state.pos(1,1) ;

% Controllers
u1 = params.mass*(params.gravity + zdes_dotdot + kd_z*(zdes_dot - z_dot) + kp_z*(zdes - z)) ;

phi_c = (-1/params.gravity)*(ydes_dotdot + kd_y*(ydes_dot - y_dot) + kp_y*(ydes - y)) ;
phi_c_dot = 0 ;
phi_c_dotdot = 0;

u2 = params.Ixx*(phi_c_dotdot + kd_phi*(phi_c_dot - state.omega) + kp_phi*(phi_c - state.rot));


end

