function [coef, A, b] = getCoef(waypoints)
% Creates matrix A, b and solves for the coefficient vector coef.

n = size(waypoints,1)-1;

% b matrix is easy, it is just the waypoints repeated in a patter
% (note waypoints is passed one component (x,y,z) at a time, so
% this function would be called three times (once for x, y, and z)
b = zeros(1,8*n);
for i=1:n
    b(1,i) = waypoints(i);
    b(1,i+n) = waypoints(i+1);
end

% A matrix is built up from all the constraints
A=zeros(8*n,8*n);

% Constraint 1 ==> Pi(t=0) = wi for all i=1:n
% Ex: P1(0) = w1, a11 = w1
% Ex: A(1,:)=[1 0 0 0 0 0 0 0 zero(1,8*(n-1))]
% Ex: b(1)=w1
for i=1:n
    A(i,((i-1)*8)+1:i*8) = polyT(8,0,0);
end

% Constraint 2 ==> Pi(t=1) = wi+1 for all i=1:n
% Ex: P1(1) = w2, a11+a12+�+a18 = w2
% Ex: A(n+1,:)=[1 1 1 1 1 1 1 1 zero(1,8*(n-1))]
% Ex: b(n+1)=w2
for i=1:n
    A(i+n,((i-1)*8)+1:i*8) = polyT(8,0,1);
end

% Constraint 3 ==> P1_k(t=0) = 0 for all k=1..3 (derivative)
% Ex: P1_1(t=0)=0, a12 = 0
% Ex: A(2*n+1,:)=[0 1 0 0 0 0 0 0 zero(1,8*(n-1))]
% Ex: b(2*n+1)=0
for k=1:3
    A(2*n+k,1:8) = polyT(8,k,0);
end

% Constraint 4 ==> Pn_k(t=1) = 0 for all k=1..3 (derivative)
% Ex: Pn_1(t=1)=0, a12 + 2a13 + 3a14 +�+ 7a18 = 0
% Ex: A(2*n+3+1,:)=[zero(1,8*(n-1)) 0 1 2 3 4 5 6 7]
% Ex: b(2*n+3+1)=0
for k=1:3
    A(2*n+3+k,(end-7):end) = polyT(8,k,1);
end

% Constraint 5 ==> Pi-1_k(t=1) = Pi_k(t=0) for all i=2..n and k=1..6
% Ex: P1_1(t=1)-P2_1(t=0) = 0, a12 + 2a13 +�+7a18 - a22 = 0
% Ex: A(2*n+6+1,)=[0 1 2 3 4 5 6 7 0 -1 0 0 0 0 0 0 zeros]
% Ex: b(2*n+6+1)=0
for i=2:n
    for k=1:6
        A(2*n+6+(i-2)*6+k, (i-2)*8+1:((i-2)*8+n*n)) = [polyT(8,k,1) -polyT(8,k,0)];
    end
end

% Now solve for the coefficients
coef = A\b';