function [coeff, A, b] = get_coeff_kaustav(waypoints)
        
        % Number of waypoints
        n = size(waypoints,2)- 1 ; % If there are n+1 waypoints, then there are n polynomials between them
        
        % A matrix consists of all the constants of polynomial
        % Ax = b
        A = zeros(8*n,8*n);
        b = zeros(3,8*n);
        for i=1:n
            b(:,i) = waypoints(:,i);
            b(:,i+n) = waypoints(:,i+1);
        end
        
        row=1;
        
        % Constraint 1
        % X(t = 0) = waypoint_i for i = 1:n
        % A(1,:) = [1 0 0 0 0 0 0 0 zeros(1,8*(n-1))]  
        % b(1,:) = waypoint_i
        for i=1:n
            A(row,(8*(i-1)+1 : 8*i)) = polyT(8,0,0);
            row = row + 1;
        end
        
        % Constraint 2
        % X(t = 1) = waypoint_i+1 for i = 1:n
        % A(n+1,:) = [1 1 1 1 1 1 1 1 zeros(1,8*(n-1)) 
        % b(n+1) = waypoint_i+1
        for i=1:n
            A(row,(8*(i-1)+1:8*i)) = polyT(8,0,1);
            row = row + 1 ;
        end
        
        % Constraint 3
        %X0_dot(t=0) = 0
        %X0_ddot(t=0) = 0
        %X0_dddot(t=0) = 0
        %Velocity, acc and jerk at starting point(t=0) are zero
        i = 1 ;
        for k = 1:3
            A(row,(8*(i-1)+1:8*i)) = polyT(8,k,0) ; %/max(polyT(8,k,0)); % %??????
            row = row + 1;
        end
        
        % Constraint 4
        %Xn_dot(t=1) = 0
        %Xn_ddot(t=1) = 0
        %Xn_dddot(t=1) = 0
        % Velocity, acc and jerk at last point(t=1)are zero
        i = n ;
        for k = 1:3
            A(row,8*(i-1)+1:8*i) = polyT(8,k,1);
            row = row + 1 ;
        end
        
        %Constraint 5
        % X_{i-1}(t=1) = X_{i}(t=0) for all i = 2..n and k = 1..6
        for i = 1:n-1
            for k = 1:6 
                A(row,8*(i-1)+1:8*(i-1)+16) = horzcat(polyT(8,k,1) , -polyT(8,k,0));
                row = row + 1 ;
            end
        end
        
        coeff = A\b' ;
                
end